const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const app = express();
const port = process.env.PORT || 3000;

// MySQL connection setup
const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});

// Connect to MySQL
db.connect((err) => {
    if (err) {
        console.error('Database connection failed: ' + err.stack);
        return;
    }
    console.log('Connected to the MySQL database');
});

// Middleware to parse JSON requests
app.use(express.json());

// Serve static files (e.g., HTML, CSS, JS) from the public folder
app.use(express.static(path.join(__dirname, '../public')));

// Route to get data from the USER table
app.get('/getData', (req, res) => {
    db.query('SELECT * FROM USER', (err, results) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(results); // Return results from the database query
    });
});

// Sample route for health check
app.get('/health', (req, res) => {
    res.json({ status: 'OK', message: 'Server is running and connected to MySQL.' });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});